#Requires -module CISDSC
#Requires -RunAsAdministrator

<#
    .DESCRIPTION
    Applies CIS Level one benchmarks for Microsoft Windows Server 2022 Member Server build 21H2 with no exclusions.
    Exclusion documentation can be found in the docs folder of this module.
#>

Configuration Microsoft_Windows_Server_2022_Member_Server_21H2_CIS_L1
{
    Import-DSCResource -ModuleName 'CISDSC' -Name 'CIS_Microsoft_Windows_Server_2022_Member_Server_Release_21H2'

    node 'localhost'
    {
        CIS_Microsoft_Windows_Server_2022_Member_Server_Release_21H2 'CIS Benchmarks'
        {
            cis2315AccountsRenameadministratoraccount = 'CISAdmin'
            cis2316AccountsRenameguestaccount         = 'CISGuest'
            cis2375LegalNoticeCaption                 = 'Legal Notice'
            cis2374LegalNoticeText                    = @"
By connecting to this server, you agree to the following terms:
Authorized Use: Only authorized users may access this server. Unauthorized use is prohibited and may result in legal action.
Privacy: Any personal data collected during this session will be handled in accordance with our Privacy Policy.
Liability: The server administrators are not responsible for any data loss or damage incurred during your session.
Compliance: You must comply with all relevant laws and server policies while connected.
If you do not agree to these terms, please disconnect immediately.
"@
        }
    }
}

Microsoft_Windows_Server_2022_Member_Server_21H2_CIS_L1
Start-DscConfiguration -Path '.\Microsoft_Windows_Server_2022_Member_Server_21H2_CIS_L1' -Verbose -Wait -Force

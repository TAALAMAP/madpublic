try {
    #Copy Folder to Module path
    Copy-Item -Path "AuditPolicyDsc" -Destination "C:\Program Files\WindowsPowerShell\Modules\AuditPolicyDsc" -Recurse -Force
    Copy-Item -Path "CISDSC" -Destination "C:\Program Files\WindowsPowerShell\Modules\CISDSC" -Recurse -Force
    Copy-Item -Path "SecurityPolicyDsc" -Destination "C:\Program Files\WindowsPowerShell\Modules\SecurityPolicyDsc" -Recurse -Force

    Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\CISDSC' -Recurse | Unblock-File
    Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\SecurityPolicyDsc' -Recurse | Unblock-File
    Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\AuditPolicyDsc' -Recurse | Unblock-File

    #Set registry Key for long DSC
    Set-Item -Path WSMan:\localhost\MaxEnvelopeSizeKb -Value 2048
    winrm quickconfig -quiet

    Import-module "CISDSC"
    Set-Location -Path "C:\Program Files\WindowsPowerShell\Modules\CISDSC\3.1.1\examples\"
    powershell.exe -executionpolicy bypass -file CIS_Microsoft_Windows_Server_2022_Member_Server_Release_21H2.ps1



}
catch {
    <#Do this if a terminating exception happens#>
}

